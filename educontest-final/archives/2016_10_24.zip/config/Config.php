<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/26/16
 * Time: 11:20 AM
 */

//Config file that has all the DB information on it.

class Config{

    const DSN = "mysql:host=localhost;dbname=educontest_test";
    const DB_USERNAME = "root";
    const DB_PASSWORD = "root";
    
    public static function init(){
        define("ENCRYPTION_KEY", "%2K*vb^&d#02PMn6%^Dl1*%$#)_#$@dva");
        date_default_timezone_set('America/New_York');
    }

}