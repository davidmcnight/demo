/**
 * Created by dmcnight on 10/4/16.
 */
edu.controller('SchoolController', ['$scope','$http', function($scope, $http) {

    $scope.signedUpCompetition = [];
    $scope.notSignedUpCompetition = [];
    
    $scope.sample_pdf = {
        '3rd Grade': 'm3-11.pdf',
        '4th Grade': 'm4-11.pdf',
        '5th Grade': 'm5-11.pdf',
        '6th Grade': 'm6-11.pdf',
        '7th Grade': 'm7-11.pdf',
        'Pre-Algebra': 'pre-11.pdf',
        'Algebra 1': 'a1-11.pdf',
        'Algebra 2': 'a2-11.pdf',
        'Geometry': 'gt-11.pdf',
        'Advanced Math': 'amt-11.pdf'
    }

    $scope.currentPage = 1;
    $scope.pageSize = 20;
    $scope.showClasses = false;

    $scope.classRegSuccess = false;
    $scope.classTestSuccess = false;

    $scope.getSchool = function (id) {
        $http.get("/api/School/" + id).success(function (response) {
            $scope.school = response;
            $scope.getCompetitionListsForSchool();
            $scope.getTestListsForSchool();
            console.log($scope.school)
        });
    }

    $scope.getAllSchools = function () {
        $http.get("/api/School/").success(function (response) {
            $scope.schools = response;
            console.log($scope.schools)
        });
    }

    $scope.getAllGrades = function () {
        $http.get("/api/Grade").success(function (response) {
            $scope.grades = response;
            console.log($scope.grades)
        });
    }
    
    $scope.getActiveYear = function () {
        $http({
            url: "/api/find/Year",
            method: "GET",
            params:  {"getActiveYear": 1}
        }).then(function successCallback(response){
            $scope.activeYear = response.data;
        });

    }

    $scope.getCompetitionsByYear = function () {
        $http({
            url: "/api/find/Competition",
            method: "GET",
            params:  {"year": 1}
        }).then(function successCallback(response){
            console.log(response.data);
           $scope.competitions = response.data;
        });

    }

    $scope.getTestsByYear = function () {
        $http({
            url: "/api/find/Test",
            method: "GET",
            params:  {"year": 1}
        }).then(function successCallback(response){
            console.log(response.data);
            $scope.tests = response.data;
        });

    }

    $scope.getCompetitionListsForSchool = function () {
        $http({
            url: "/api/unique/SchoolCompetition/SignedUp",
            method: "GET",
            params:  {"schoolId": $scope.school.schoolId}
        }).then(function successCallback(response){

            $scope.signedUpCompetition = response.data.signedUp;
            $scope.notSignedUpCompetition = response.data.notSignedUp;
            console.log($scope.notSignedUpCompetition[0]);

        });

    };

    $scope.getTestListsForSchool = function () {
        $http({
            url: "/api/unique/SchoolTest/SignedUp",
            method: "GET",
            params:  {"schoolId": $scope.school.schoolId}
        }).then(function successCallback(response){
            $scope.signedUpTest = response.data.signedUp;
            $scope.notSignedUpTest = response.data.notSignedUp;
        });

    };

    
    $scope.createSchoolCompetition = function (competition) {
        console.log(competition);
        var data = {};
        data["school"] = $scope.school;
        data["competition"] = competition;
        $http.post("/api/unique/SchoolCompetition/", data).success(function (response) {
            $scope.getCompetitionListsForSchool();
            $scope.classRegSuccess = false;
            $scope.classRegSuccess = true;

        }, function errorCallback(response) {
            console.log("Fail");
        });
    }

    $scope.createSchoolTest = function (test) {
        var data = {};
        data["school"] = $scope.school;
        data["test"] = test;
        $http.post("/api/unique/SchoolTest/", data).success(function (response) {
            $scope.getTestListsForSchool();
            $scope.testRegSuccess = false;
            $scope.testRegSuccess = true;
        }, function errorCallback(response) {
            console.log("Fail");
        });
    }

    $scope.deleteSchoolCompetition = function (competition) {

        $http.delete("/api/unique/SchoolCompetition/"
            + $scope.school.schoolId
            + "/"
            + competition.competitionId)
            .success(function (response) {
                $scope.getCompetitionListsForSchool();
                console.log("Competition DELETED");
        }, function errorCallback(response) {
            console.log("Fail");
        });
    }

    $scope.deleteSchoolTest = function (test) {

        $http.delete("/api/unique/SchoolTest/"
            + $scope.school.schoolId
            + "/"
            + test.testId)
            .success(function (response) {
                $scope.getTestListsForSchool();
                console.log("Competition DELETED");
            }, function errorCallback(response) {
                console.log("Fail");
            });
    }
    
    
    
    //add to sign up list
   // $scope.signedUpCompetition.push(competition);
    //remove from list
    // $scope.notSignedUpCompetition.splice(index, 1);

    $scope.registerCompetitions = function () {
        //iterate through the objects
        angular.forEach($scope.signedUpCompetition, function(competition) {
            var data = {};
            data["school"] = $scope.school;
            data["competition"] = competition;
            $http.post("/api/unique/SchoolCompetition/", data).success(function (response) {
                console.log("Success");
                // $window.location.href = '/';
            }, function errorCallback(response) {
                console.log("Fail");
            });
        });
    }
    
}]);