<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/12/16
 * Time: 4:35 PM
 */
require_once "templates/layout/header.php"

?>

<div class="container col-xs-9 col-xs-offset-1 pt2 mt3" id="main"
ng-app="edu" ng-controller="registrationController">
    <div class="row p1 col-xs-12 ">
        <div class="col-md-12 mb1 row">
            <h1 class="col-xs-12">Sign In</h1>
        </div>
        <div class="col-xs-12 col-md-12 row">
            <form method="post" action="/verify" name="user_reg_form" class="p1">
                <div class="col-xs-12 row mb1">
                    <!-- School Name -->
                    <div class="col-xs-12 col-md-4 mb1 row">
                        <label class="control-label">Email Address</label>
                        <input ng-model="sign_in.email" name="username"
                               type="text" class="form-control" placeholder="myschool@school.com" >
                    </div>
                </div>
                <div class="col-xs-12 row mb1">
                    <!-- School Name -->
                    <div class="col-xs-12 col-md-4 mb1 row">
                        <label class="control-label">Password</label>
                        <input ng-model="sign_in.password" name="password"
                               type="password" class="form-control" placeholder="myschool@school.com" >
                    </div>
                </div>
                <div class=" col-xs-12 control-container row">
                    <input type="submit"  value=" Sign In" class="btn btn-primary" ng-disabled="!(
                                !!sign_in.password &&
                                !!sign_in.email
                            )">


            </form>
        </div>
    </div>
</div>