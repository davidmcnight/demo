<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 9:48 AM
 */

require_once "templates/layout/header.php";
?>


<div class="container pt2 mt3 pb3" id="main" ng-app="edu" ng-controller="SchoolController"
     ng-init="getSchool(<?php echo $_SESSION['school_id'] ?>) ">
    <button class="btn btn-warning" ng-click="getTestListsForSchool()">TEST</button>
    <div class="jumbotron">
        <h2>{{school.name}}'s Dashboard</h2>
    </div>

    <!-- NG-IF if they are not sign up   -->
    <div ng-init="getActiveYear()" class="col-xs-12 pb2 row">
        <button class="btn btn-primary " >
            Register for: {{activeYear.description}}
        </button>
    </div>

    <div class="row">
        <div class="col-xs-12">
            <div ng-show="classRegSuccess" class="alert alert-success " role="alert">
                <p>Class successfully registered. </p>
            </div>
        </div>
        <div class="col-xs-12">
            <div ng-show="testRegSuccess" class="alert alert-success" role="alert">
                <p>Practice test successfully registered. </p>
            </div>
        </div>
    </div>

    <div class="col-xs-6">
        <h2>Sign Up for Classes</h2>
    </div>
    <div class="col-xs-6">
        <h2>Sign Up for Practice Tests</h2>
    </div>
    <div class="row">
        <div  class="col-xs-12 col-md-3" ">
            <div class="panel panel-default">
                <div class="panel-heading">
                   Not Registered
                </div>
                <table class="table table-striped">
                    <tr ng-repeat="c in notSignedUpCompetition">
                        <td>{{c.grade.name}}</td>
                        <td><button class="btn btn-primary"
                                    ng-click="createSchoolCompetition(c)">Add
                            </button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div  class="col-xs-12 col-md-3">
            <div class="panel panel-default">
                <div class="panel-heading">
                  Registered
                </div>
                <table class="table table-striped">
                    <tr ng-repeat="c2 in signedUpCompetition">
                        <td>{{c2.grade.name}}</td>
                        <td><button class="btn btn-danger"
                                    ng-click="deleteSchoolCompetition(c2)">Delete
                            </button>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    <div class="row">
        <div  class="col-xs-12 col-md-3" ">
        <div class="panel panel-default">
            <div class="panel-heading">
                Not Registered
            </div>
            <table class="table table-striped">
                <tr ng-repeat="t in notSignedUpTest">
                    <td>{{t.grade.name}}</td>
                    <td><button class="btn btn-primary"
                                ng-click="createSchoolTest(t)">Add
                        </button>
                    </td>
                </tr>
            </table>
        </div>
    </div>
    <div  class="col-xs-12 col-md-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                Registered
            </div>
            <table class="table table-striped">
                <tr ng-repeat="t2 in signedUpTest">
                    <td>{{t2.grade.name}}</td>
                    <td><button class="btn btn-danger"
                                ng-click="deleteSchoolTest(t2)">Delete
                        </button>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>


