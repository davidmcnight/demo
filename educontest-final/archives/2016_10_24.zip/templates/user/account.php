<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/13/16
 * Time: 4:38 PM
 */



require_once "templates/layout/header.php";
//printNicely($log);
//printNicely($_SESSION);
?>

<div class="container pt2 mt3" id="main" ng-app="edu" ng-controller="SchoolController"
     ng-init="getSchool(<?php echo $_SESSION['school_id'] ?>)">
    <div class="row col-xs-12">
        <div class="jumbotron">
            <h2>{{school.name}}</h2>
        </div>
        <div class="col-xs-7">
            <div class="panel panel-default">
                <div class="panel-heading">
                    School Info
                </div>
                <table class="table table-striped">
                    <tr>
                        <td>League:</td>
                        <td class="bold">{{school.league.description}}</td>
                    </tr>
                    <tr>
                        <td>Contact:</td>
                        <td class="bold">{{school.contact}}</td>
                    </tr>
                    <tr>
                        <td>Billing Name:</td>
                        <td class="bold">{{school.billingName}}</td>
                    </tr>
                    <tr>
                        <td>Purchase Order:</td>
                        <td class="bold">{{school.purchaseOrder}}</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td class="bold">{{school.school_email}}</td>
                    </tr>
                    <tr>
                        <td>Phone:</td>
                        <td class="bold">{{school.phone}}</td>
                    </tr>
                    <tr>
                        <td>Fax:</td>
                        <td class="bold">{{school.fax}}</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="col-xs-5">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Users
                </div>
                <table class="table table-striped">
                    <tr ng-repeat="user in school.users">
                        <td>Email:</td>
                        <td class="bold">{{user.email}}</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Shipping Info
                </div>
                <table class="table table-striped">
                    <tr>
                        <td>Address 1:</td>
                        <td class="bold">{{school.shippingAddress.address1}}</td>
                    </tr>
                    <tr>
                        <td>Address 2:</td>
                        <td class="bold">{{school.shippingAddress.address2}}</td>
                    </tr>
                    <tr>
                        <td>City:</td>
                        <td class="bold">{{school.shippingAddress.city}}</td>
                    </tr>
                    <tr>
                        <td>State:</td>
                        <td class="bold">{{school.shippingAddress.state}}</td>
                    </tr>
                    <tr>
                        <td>Zip:</td>
                        <td class="bold">{{school.shippingAddress.zip}}</td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Billing Info
                </div>
                <table class="table table-striped">
                    <tr>
                        <td>Address 1:</td>
                        <td class="bold">{{school.billingAddress.address1}}</td>
                    </tr>
                    <tr>
                        <td>Address 2:</td>
                        <td class="bold">{{school.billingAddress.address2}}</td>
                    </tr>
                    <tr>
                        <td>City:</td>
                        <td class="bold">{{school.billingAddress.city}}</td>
                    </tr>
                    <tr>
                        <td>State:</td>
                        <td class="bold">{{school.billingAddress.state}}</td>
                    </tr>
                    <tr>
                        <td>Zip:</td>
                        <td class="bold">{{school.billingAddress.zip}}</td>
                    </tr>
                </table>
            </div>
        </div>

