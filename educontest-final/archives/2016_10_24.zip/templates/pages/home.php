<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/3/16
 * Time: 10:06 AM
 */
require_once "templates/layout/header.php"

?>

<div class="container col-xs-9 col-xs-offset-1 pt2 mt3" id="main" ng-app="edu" ng-controller="eduController">
    <div class="row p1">
        <div class="col-xs-6">
            <img src="/public/assets/img/educontestpic.jpg">
        </div>
        <div class="col-xs-5 pull-right"  >
            <h3>Customer Testimonials</h3>
            <p>"Yours is one of the best run contests in which we participate."</p>
            <p> "Our students credit these tests to improving their standardized test results."</p>
            <p> "Thank you so much! We can't wait till next year!"</p>
            <p> "We have been very pleased with your service and have gotten great results from your contests."</p>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-6">
            <div class="p1 bucket">
                <h3>See Your Test Results</h3>
                <p>See your Test Results by <a href="/results">clicking here</a></p>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="p1 bucket">
                <h3>Register Online</h3>
                <p>Simply <a href="/registration">create an account</a> to enter the competition.</p>
            </div>
        </div>
    </div>
</div>

