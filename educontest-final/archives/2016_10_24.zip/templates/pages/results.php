<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/3/16
 * Time: 1:04 PM
 */

require_once "templates/layout/header.php";

?>

<div class="container col-xs-9 col-xs-offset-1 pt2 mt3" id="main" ng-app="edu" ng-controller="eduController">
    <div class="row p1">
        <h1 class="jumbotron">
            Test Results... coming soon
        </h1>
    </div>
</div>
