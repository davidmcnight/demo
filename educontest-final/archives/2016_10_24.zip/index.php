<?php
/**
 * Step 1: Require the Slim Framework
 *
 * If you are not using Composer, you need to require the
 * Slim Framework and register its PSR-0 autoloader.
 *
 * If you are using Composer, you can skip this step.
 */
require 'Slim/Slim.php';

\Slim\Slim::registerAutoloader();

require_once "includes.php";
$factory = Factory::getInstance();

Config::init();
$log = new Login();

/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \Slim\Slim();

/**
 * Step 3: Define the Slim application routes
 *
 * Here we define several Slim application routes that respond
 * to appropriate HTTP request methods. In this example, the second
 * argument for `Slim::get`, `Slim::post`, `Slim::put`, `Slim::patch`, and `Slim::delete`
 * is an anonymous function.
 */

//DEBUGGING
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function printNicely($value){
    print nl2br(print_r($value, true));
}




//SET CONDITIONS
\Slim\Route::setDefaultConditions(array(
    'class' => '[a-zA-Z]{3,}',
    'schoolId' =>'[0-9]{0,10000}',
    'competitionId' =>'[0-9]{0,10000}',
    'testId' =>'[0-9]{0,10000}',
    'id' =>'[0-9]{0,10000}'
));



//PAGES
$app->get(
    '/',
    function () use ($app){
        $app->render('pages/home.php');
    }
);

$app->get(
    '/about',
    function () use ($app){
        $app->render('pages/about.php');
    }
);

$app->get(
    '/samples',
    function () use ($app){
        $app->render('pages/samples.php');
    }
);

$app->get(
    '/contact',
    function () use ($app){
        $app->render('pages/contact.php');
    }
);

$app->get(
    '/results',
    function () use ($app){
        $app->render('pages/results.php');
    }
);

//registration views
$app->get(
    '/registration',
    function () use ($app){
        $app->render('registration/registration.php');
    }
);

$app->get(
    '/users/sign-in',
    function () use ($app, $log){
        if($log->isUserLoggedIn()) {
            $app->render('pages/home.php');
        }else{
            $app->render('registration/sign-in.php');
        }
    }
);

$app->get(
    '/logout',
    function () use ($app, $log) {
        $log->logout();
        $app->redirect("/");
    }
);


//admin views
$app->get(
    '/admin/school/',
    function () use ($app){
        $app->render('admin/school/master.php');
    }
);

$app->get(
    '/admin/school/:id',
    function ($id) use ($app){
        $app->render('admin/school/detail.php', array('id' => $id));
    }
);


//USER PAGES

//account
$app->get(
    '/users/account/:schoolId',
    function ($schoolId) use ($app, $log){
        if($log->isUserLoggedIn() && $schoolId == $_SESSION["school_id"]) {
            $app->render('user/account.php', array('school_id' => $schoolId));
        }else{
            $app->redirect("/");
        }
    }
);

//dashboard
$app->get(
    '/users/dashboard/:schoolId',
    function ($schoolId) use ($app, $log){
        if($log->isUserLoggedIn() && $schoolId == $_SESSION["school_id"]) {
            $app->render('user/dashboard.php', array('school_id' => $schoolId));
        }else{
            $app->redirect("/");
        }
    }
);



/* AUTHENTICATION */
$app->post(
    '/verify',
    function () use ($app, $log) {
        if (!empty($_POST['username']) && !empty($_POST['password'])) {
            $log->login($_POST['username'], $_POST['password']);
        }
        if($log->isUserLoggedIn()){
            $app->redirect("/");
        }else{
//            $app->render('brewery/brewery.php', array('fail' => true));
        }
    }
);



//BASIC ROUTES ---> These routes call methods in the IRestService Interface




//GET ALL IEduObject
$app->get(
    '/api/:class/',
    function ($class) use ($app, $factory){
        $service = Factory::createService($class);
        echo json_encode($service->getAll());
    }
);

//GET IEduObject by ID
$app->get(
    '/api/:class/:id',
    function ($class, $id) use ($app){
        echo json_encode(Factory::createService($class)->get($id));
    }
);


//FIND
$app->get(
    '/api/find/:class/',
    function ($class) use ($app, $factory){
        $service = Factory::createService($class);
        echo  json_encode($service->find($app->request->params()));
    }
);



//UNIQUE ROUTES ---> These routes call methods that are NOT in the IRestService Interface

// POST route
$app->post(
    '/api/:class',
    function ($class) use ($app) {
        $data = json_decode($app->request->getBody(), true);
        $service = Factory::createService($class);
        $object = Factory::createObject($class,  $data);
        $service->post($object);
    }
);



//Unique Competition Calls
$app->post(
    '/api/unique/SchoolCompetition/',
    function () use ($app) {
        $data = json_decode($app->request->getBody(), true);
        $service = Factory::createService("Competition");
        $school = Factory::createSchool($data);
        $competition = Factory::createCompetition($data["competition"]);
        $service->createSchoolCompetition($school, $competition);
    }
);

$app->post(
    '/api/unique/SchoolTest/',
    function () use ($app) {
        $data = json_decode($app->request->getBody(), true);
        $service = Factory::createService("Test");
        $school = Factory::createSchool($data);
        $test = Factory::createTest($data["test"]);
        $service->createSchoolTest($school, $test);
    }
);

$app->delete(
    '/api/unique/SchoolCompetition/:schoolId/:competitionId',
    function ($schoolId, $competitionId) use ($app) {
        $service = Factory::createService("Competition");
        $service->deleteSchoolCompetition($schoolId, $competitionId);
    }
);

$app->delete(
    '/api/unique/SchoolTest/:schoolId/:testId',
    function ($schoolId, $testId) use ($app) {
        $service = Factory::createService("Test");
        $service->deleteSchoolTest($schoolId, $testId);
    }
);


$app->get(
    '/api/unique/SchoolCompetition/SignedUp',
    function () use ($app) {
        $data = $app->request->params();
        $service = Factory::createService("Competition");
        echo json_encode($service->getSchoolCompetitionLists($data["schoolId"]));
    }
);


$app->get(
    '/api/unique/SchoolTest/SignedUp',
    function () use ($app) {
        $data = $app->request->params();
        $service = Factory::createService("Test");
        echo json_encode($service->getSchoolTestLists($data["schoolId"]));
    }
);


// PUT route
$app->put(
    '/put',
    function () {
        echo 'This is a PUT route';
    }
);

// PATCH route
$app->patch('/patch', function () {
    echo 'This is a PATCH route';
});

// DELETE route
$app->delete(
    '/delete',
    function () {
        echo 'This is a DELETE route';
    }
);

/**
 * Step 4: Run the Slim application
 *
 * This method should be called last. This executes the Slim application
 * and returns the HTTP response to the HTTP client.
 */
$app->run();
