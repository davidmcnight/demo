<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/12/16
 * Time: 1:11 PM
 */

class Login
{

    public function __construct()
    {
        // create/read session, absolutely necessary
        session_start();
        // check the possible login actions:
        // if user tried to log out (happen when user clicks logout button)
        if (isset($_GET["logout"])) {
            $this->doLogout();
        }
        // login via post data (if user just submitted a login form)
        elseif (isset($_POST["login"])) {
            $this->dologinWithPostData();
        }
    }
    /**
     * log in with post data
     */
    public function login($username, $password)
    {
        // check login form contents
        printNicely($username);
        printNicely($password);




        // create a database connection, using the constants from config/db.php (which we loaded in index.php)
        $db = Database::getInstance();

        // database query, getting all the info of the selected user (allows login via email address in the
        // username field)
        $password = Encryption::ENCRYPT_PASSWORD($password);

        $query = "SELECT * FROM user WHERE email = '$username' AND password = '$password'";
        $stmt = $db->query($query);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        // if this user exists
        if (count($result) > 0) {
            // using PHP 5.5's password_verify() function to check if the provided password fits
            // the hash of that user's password// write user data into PHP SESSION (a file on your server)
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;
            $_SESSION['logged_in'] = 1;
            $_SESSION['admin'] = $result["admin"];
            $_SESSION['school_id'] = $result["schoolId"];
        }


    }

    /**
     * perform the logout
     */
    public function logout()
    {
        // delete the session of the user
        $_SESSION = array();
        session_destroy();
        // return a little feeedback message
    }
    /**
     * simply return the current state of the user's login
     * @return boolean user's login status
     */
    public function isUserLoggedIn()
    {

        if (isset($_SESSION['logged_in']) AND $_SESSION['logged_in'] == 1) {
            return true;
        }
        // default return
        return false;
    }

    public function isAdmin()
    {
        if (isset($_SESSION['admin']) AND $_SESSION['admin'] == 1) {
            return true;
        }
        // default return
        return false;
    }
}