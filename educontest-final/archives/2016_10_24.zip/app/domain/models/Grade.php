<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 11:18 AM
 */
class Grade implements JsonSerializable, IEduObject{


    private $gradeId;
    private $name;
    private $order;
    private $createdAt;
    private $updatedAt;

    /**
     * Grade constructor.
     * @param $gradeId
     * @param $name
     * @param $order
     */
    public function __construct($gradeId, $name, $order){
        $this->gradeId = $gradeId;
        $this->name = $name;
        $this->order = $order;
    }


    public function setFields($results)
    {
        // TODO: Implement setFields() method.
    }

    public function getSource()
    {
        // TODO: Implement getSource() method.
    }

    public function getValuesArray()
    {
        // TODO: Implement getValuesArray() method.
    }

    public function jsonSerialize(){
        return get_object_vars($this);
    }


}