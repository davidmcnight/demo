<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 9:53 AM
 */
class Year implements IEduObject, JsonSerializable{

    private $yearId; //
    private $description; //2016-2017
    private $year;
    private $open;
    private $resultsArePublic;
    private $openTest;
    private $createdAt;
    private $updatedAt;

    /**
     * Year constructor.
     * @param $yearId
     * @param $description
     * @param $year
     * @param $open
     * @param $resultsArePublic
     * @param $openTest
     */
    public function __construct($yearId, $description, $year, $open, $openTest , $resultsArePublic){
        $this->yearId = $yearId;
        $this->description = $description;
        $this->year = $year;
        $this->open = $open;
        $this->openTest = $openTest;
        $this->resultsArePublic = $resultsArePublic;
    }

    /**
     * @return mixed
     */
    public function getYearId()
    {
        return $this->yearId;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @return mixed
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * @return mixed
     */
    public function getOpen()
    {
        return $this->open;
    }

    /**
     * @return mixed
     */
    public function getResultsArePublic()
    {
        return $this->resultsArePublic;
    }

    /**
     * @return mixed
     */
    public function getOpenTest()
    {
        return $this->openTest;
    }
    
    


    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
       return 'grade';
    }

    public function getValuesArray(){
        return get_object_vars($this);
    }

    public function jsonSerialize(){
        return get_object_vars($this);
    }



}