<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/30/16
 * Time: 1:25 PM
 */
class League implements JsonSerializable, IEduObject{
    
    private $leagueId;
    private $description;
    private $createdAt;
    private $updatedAt;

    /**
     * League constructor.
     * @param $leagueId
     * @param $description
     */
    public function __construct($leagueId, $description){
        $this->leagueId = $leagueId;
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getLeagueId(){
        return $this->leagueId;
    }

    /**
     * @return mixed
     */
    public function getDescription(){
        return $this->description;
    }
    
    

    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        return "league";
    }

    function jsonSerialize(){
        return get_object_vars($this);
    }

    public function getValuesArray()
    {
        // TODO: Implement getValuesArray() method.
    }


}