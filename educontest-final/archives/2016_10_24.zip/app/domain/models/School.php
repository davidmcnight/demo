<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 9:32 AM
 */

class School implements JsonSerializable, IEduObject{

    private $schoolId;
    private $name;
    private $contact;
    private $billingName;
    private $purchaseOrder;
    private $schoolEmail;
    private $phone;
    private $fax;
    private $shippingAddress;
    private $billingAddress;
    private $league;
    private $users;
    private $oldSchoolId;
    private $createdAt;
    private $updatedAt;

    /**
     * School constructor.
     * @param $schoolId
     * @param $name
     * @param $contact
     * @param $billingName
     * @param $purchaseOrder
     * @param $email
     * @param $phone
     * @param $fax
     * @param $shippingAddress
     * @param $billingAddress
     * @param $league
     */
    public function __construct($schoolId, $name, $contact, $billingName,
                                $purchaseOrder, $schoolEmail, $phone, $fax){
        $this->schoolId = $schoolId;
        $this->name = $name;
        $this->contact = $contact;
        $this->billingName = $billingName;
        $this->purchaseOrder = $purchaseOrder;
        $this->schoolEmail = $schoolEmail;
        $this->phone = $phone;
        $this->fax = $fax;
    }

    public function getValuesArray(){
        
    }



    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }


    public function jsonSerialize(){
        return get_object_vars($this);
    }

    /**
     * @param mixed $shippingAddress
     */
    public function setShippingAddress($shippingAddress){
        $this->shippingAddress = $shippingAddress;
    }

    /**
     * @param mixed $billingAddress
     */
    public function setBillingAddress($billingAddress){
        $this->billingAddress = $billingAddress;
    }

    /**
     * @param mixed $league
     */
    public function setLeague($league){
        $this->league = $league;
    }

    /**
     * @return mixed
     */
    public function getSchoolId()
    {
        return $this->schoolId;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @return mixed
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * @return mixed
     */
    public function getBillingName()
    {
        return $this->billingName;
    }

    /**
     * @return mixed
     */
    public function getPurchaseOrder()
    {
        return $this->purchaseOrder;
    }

    /**
     * @return mixed
     */
    public function getSchoolEmail()
    {
        return $this->school_email;
    }

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @return mixed
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * @return mixed
     */
    public function getShippingAddress()
    {
        return $this->shippingAddress;
    }

    /**
     * @return mixed
     */
    public function getBillingAddress()
    {
        return $this->billingAddress;
    }

    /**
     * @return mixed
     */
    public function getLeague()
    {
        return $this->league;
    }

    /**
     * @return mixed
     */
    public function getOldSchoolId()
    {
        return $this->oldSchoolId;
    }

    /**
     * @return mixed
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @return mixed
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * @return mixed
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * @param mixed $users
     */
    public function setUsers($users)
    {
        $this->users = $users;
    }


    
 

}