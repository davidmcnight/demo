<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 9:45 AM
 */
class ShippingAddress implements JsonSerializable, IEduObject{

    private $shippingAddressId;
    private $address1;
    private $address2;
    private $city;
    private $state;
    private $zip;
    private $createdAt;
    private $updatedAt;

    /**
     * ShippingAddress constructor.
     * @param $shippingAddressId
     * @param $address1
     * @param $address2
     * @param $city
     * @param $state
     * @param $zip
     */
    public function __construct($shippingAddressId, $address1, $address2, $city, $state, $zip){
        $this->shippingAddressId = $shippingAddressId;
        $this->address1 = $address1;
        $this->address2 = $address2;
        $this->city = $city;
        $this->state = $state;
        $this->zip = $zip;
    }

    /**
     * @return mixed
     */
    public function getShippingAddressId()
    {
        return $this->shippingAddressId;
    }

    /**
     * @return mixed
     */
    public function getAddress1()
    {
        return $this->address1;
    }

    /**
     * @return mixed
     */
    public function getAddress2()
    {
        return $this->address2;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @return mixed
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * @return mixed
     */
    public function getZip()
    {
        return $this->zip;
    }

    

    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }

    public function jsonSerialize(){
        return get_object_vars($this);
    }

    public function getValuesArray()
    {
        // TODO: Implement getValuesArray() method.
    }
    

}