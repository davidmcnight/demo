<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/26/16
 * Time: 11:45 AM
 */
class User implements JsonSerializable, IEduObject{

    private $id;
    private $email;
    private $password;
    private $admin;

    /**
     * User constructor.
     * @param $id
     * @param $email
     * @param $password
     * @param $admin
     */
    public function __construct($id, $email, $admin)
    {
        $this->id = $id;
        $this->email = $email;
        $this->admin = $admin;
    }


    /**
     * User constructor.
     * @param $id
     * @param $email
     * @param $password
     */


    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        return "user";
    }

    function jsonSerialize(){
        return get_object_vars($this);
    }


    /**
     * @return mixed
     */
    public function getId(){
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getEmail(){
        return $this->email;
    }

    /**
     * @return mixed
     */
    public function getPassword(){
        return $this->password;
    }

    /**
     * @param mixed $id
     */
    public function setId($id){
        $this->id = $id;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email){
        $this->email = $email;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password){
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getAdmin()
    {
        return $this->admin;
    }

    /**
     * @param mixed $admin
     */
    public function setAdmin($admin)
    {
        $this->admin = $admin;
    }




    public function getValuesArray()
    {
        // TODO: Implement getValuesArray() method.
    }
    
    
    public function getIpAddress(){
        $ipaddress = '';
        if (getenv('HTTP_CLIENT_IP'))
            $ipaddress = getenv('HTTP_CLIENT_IP');
        else if(getenv('HTTP_X_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
        else if(getenv('HTTP_X_FORWARDED'))
            $ipaddress = getenv('HTTP_X_FORWARDED');
        else if(getenv('HTTP_FORWARDED_FOR'))
            $ipaddress = getenv('HTTP_FORWARDED_FOR');
        else if(getenv('HTTP_FORWARDED'))
            $ipaddress = getenv('HTTP_FORWARDED');
        else if(getenv('REMOTE_ADDR'))
            $ipaddress = getenv('REMOTE_ADDR');
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }
    


}