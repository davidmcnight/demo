<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 12:49 PM
 */
class Competition implements JsonSerializable, IEduObject{


    private $competitionId;
    private $year;
    private $grade;
   
    private $createdAt;
    private $updatedAt;

    /**
     * Competition constructor.
     * @param $competitionId
     * @param $year
     * @param $grade
     * @param $division
     */
    public function __construct($competitionId){
        $this->competitionId = $competitionId;
    }

    /**
     * @param mixed $year
     */
    public function setYear($year){
        $this->year = $year;
    }

    /**
     * @param mixed $grade
     */
    public function setGrade($grade){
        $this->grade = $grade;
    }

    /**
     * @return mixed
     */
    public function getCompetitionId()
    {
        return $this->competitionId;
    }

    /**
     * @return mixed
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * @return mixed
     */
    public function getGrade()
    {
        return $this->grade;
    }
    
    

    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }

    public function getValuesArray()
    {
        // TODO: Implement getValuesArray() method.
    }

    function jsonSerialize(){
        return get_object_vars($this);
    }


}