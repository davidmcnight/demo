<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 1:18 PM
 */
interface IEduObject{

    public function setFields($results);
    public function getSource();
    public function getValuesArray();
    
}