<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/21/16
 * Time: 2:15 PM
 */
class Test  implements JsonSerializable, IEduObject{

    private $testId;
    private $year;
    private $grade;
    private $createdAt;
    private $updatedAt;

    /**
     * Test constructor.
     * @param $testId
     * @param $year
     * @param $grade
     */
    public function __construct($testId){
        $this->testId = $testId;
    }

    /**
     * @return mixed
     */
    public function getTestId(){
        return $this->testId;
    }

    /**
     * @param mixed $testId
     */
    public function setTestId($testId){
        $this->testId = $testId;
    }

    /**
     * @return mixed
     */
    public function getYear(){
        return $this->year;
    }

    /**
     * @param mixed $year
     */
    public function setYear($year){
        $this->year = $year;
    }

    /**
     * @return mixed
     */
    public function getGrade(){
        return $this->grade;
    }

    /**
     * @param mixed $grade
     */
    public function setGrade($grade){
        $this->grade = $grade;
    }




    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }

    public function getValuesArray(){
        // TODO: Implement getValuesArray() method.
    }

    function jsonSerialize(){
        return get_object_vars($this);
    }


}