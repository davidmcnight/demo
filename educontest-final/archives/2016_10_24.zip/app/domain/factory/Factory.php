<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 3:52 PM
 */


/* This is the factory class. All Services or Models will be created in this class.
 * If you are creating those two categories of objects any other way than this you are doing it wrong.
 * This creates flexibility and scalability for this application. If a column is added to a table
 * and need to map it to a model class the only place we need to change the constructor outside the
 * the model class will be here.
 * Obviously if a whole new table is created -- this will change constructors in other places
 * For created a service --- we pass in the model class name and create a service from there.
 * For models we pass an array in (result from database) and child classes if it has any (School has 3)
 * Any questions consult the factory design pattern -- it is all over the web
 */

//This uses the singleton Design pattern. Sorry, if you do not like this pattern.
class Factory{

    private static $instance;

    /**
     * Protected constructor to prevent creating a new instance of the
     * *Singleton* via the `new` operator from outside of this class.
     */
    protected function __construct(){

    }
    /**
     * Returns the *Singleton* instance of this class.
     *
     * @return Singleton The *Singleton* instance.
     */
    public static function getInstance(){
        if (null === static::$instance) {
            static::$instance = new Factory();
        }
        return static::$instance;
    }

    //Creates service from model name -- thank PHP for how easy this is.
    public static function createService($className){
        if($className){
            $serviceClass = $className . "Service";
            return new $serviceClass;
        }
        return null;
    }

    //THIS FUNCTION IS ONLY USED IN THE POST routes when you do not have and ID
    //BLAME THIS ON PHP NOT ALLOWING Multiple Constructors Sigh
    public static function createObject($className, $params){
        try{
            if($className){
                switch ($className) {
                    case "User";
                        return Factory::createUser($params);
                        break;
                    case "Competition";
                        return Factory::createCompetition($params);
                        break;
                    case "School";
                        return Factory::createSchool($params);
                        break;
                    default: return null;
                }

            }
        }catch (Exception $e){
            $e->getMessage();
        }
       return null;
    }

    /* OBJECTS ASSOCIATED WITH USER REGISTRATION OR LOGGING IN */
    public static function createUser($result){
        //check if result is not null
        if($result){
            //if id is null and if not array -- creating a new on in the DB
            if(!array_key_exists("userId", $result)){
                $user = new User(
                    null,
                    $result["email"],
                    0
                );
                $user->setPassword(Encryption::ENCRYPT_PASSWORD($result['password']));
                return $user;
            }else{
               $user = new User(
                    $result["userId"],
                    $result["email"],
                    $result["admin"]
                );
                return $user;
            }
        }
        return null;
    }

    /* OBJECTS ASSOCIATED WITH SCHOOL */

    //initiates a School Object from the DB record and the below 3 objects
    public static function createSchool($result){

        if(isset($result['school'])){
            $result = $result['school'];
        }

        if($result) {
            //GET, PUT, PATCH, DELETE
            if(array_key_exists("schoolId", $result)){

                return new School($result["schoolId"],
                    $result["name"],
                    $result["contact"],
                    $result["billingName"],
                    $result["purchaseOrder"],
                    $result["schoolEmail"],
                    $result["phone"],
                    $result["fax"]
                );
            //POST
            }else{

                //CHECK FOR NON REQUIRED FIELDS
                if(!isset($result['fax'])){
                    $result['fax'] = "";
                }

                if(!isset($result['purchaseOrder'])){
                    $result['purchaseOrder'] = " ";
                }

                if(!isset($result['schoolEmail'])) {
                    $result['schoolEmail'] = " ";
                }
                
                $school = new School(null,
                    $result["name"],
                    $result["contact"],
                    $result["billingName"],
                    $result["purchaseOrder"],
                    $result["schoolEmail"],
                    $result["phone"],
                    $result["fax"]
                );

               
                //call League service to grab data if there is a league being passed
                $school->setLeague(Factory::createService("League")->get($result["school"]["league"]));

                if(array_key_exists("shipping", $result)){
                    $ship_re = $result['shipping'];
                    $shipping = Factory::createShippingAddress($ship_re);
                    $school->setShippingAddress($shipping);
                }

                if(array_key_exists("billing", $result)){
                    $bill_re = $result['billing'];
                    $billing = Factory::createBillingAddress($bill_re);
                    $school->setBillingAddress($billing);
                }

                if(array_key_exists("shipping", $result)){
                    $user_re = $result['user'];
                    $user = Factory::createUser($user_re);
                    $school->setUsers($user);
                }
              
                //set other related classes
                return $school;

            }

        }
        return null;

    }

    //initiates a League Object from the DB record
    public static function createLeague($result){
        if($result){
            return new League(
                $result["leagueId"],
                $result["description"]
            );
        }
        return null;
    }

    //initiates a Shipping Address Object from the DB record
    public static function createShippingAddress($result){
        if($result){
            //CHECK FOR NON REQUIRED FIELDS
            if(!isset($result['address2'])){$result['address2'] = "";}

            //GET,PATCH,PUT,DELETE
            if(array_key_exists("schoolId", $result)){
                return new ShippingAddress($result["shippingAddressId"],
                    $result["address1"],
                    $result["address2"],
                    $result["city"],
                    $result["state"],
                    $result["zip"]
                );
            //POST
            }else{
                return new ShippingAddress(null,
                    $result["address1"],
                    $result["address2"],
                    $result["city"],
                    $result["state"],
                    $result["zip"]
                );
            }

        }
        return null;
    }

    //initiates a Billing Address Object from the DB record
    public static function createBillingAddress($result){
        if($result) {
            //CHECK FOR NON REQUIRED FIELDS
            if(!isset($result['address2'])){$result['address2'] = "";}
            //GET,PATCH,PUT,DELETE
            if (array_key_exists("schoolId", $result)) {
                return new BillingAddress($result["billingAddressId"],
                    $result["address1"],
                    $result["address2"],
                    $result["city"],
                    $result["state"],
                    $result["zip"]
                );
            //POST
            } else {
                return new BillingAddress(null,
                    $result["address1"],
                    $result["address2"],
                    $result["city"],
                    $result["state"],
                    $result["zip"]
                );
            }
        }
        return null;

    }

    public static function createCompetition($result){

        if($result) {
                $competition = new Competition($result["competitionId"]);

                //grab Grade
                if(array_key_exists("grade", $result)) {
                    $grade_result = $result['grade'];
                    $grade = Factory::createGrade($grade_result);
                    $competition->setGrade($grade);
                }

                //Grab Year
                if(array_key_exists("year", $result)){
                    $year_result = $result['year'];
                    $year = Factory::createYear($year_result);
                    $competition->setYear($year);
                }
                return $competition;

        }

        return null;
    }

    public static function createTest($result){

        if($result) {
            $test = new Test($result["testId"]);

            //grab Grade
            if(array_key_exists("grade", $result)) {
                $grade_result = $result['grade'];
                $grade = Factory::createGrade($grade_result);
                $test->setGrade($grade);
            }

            //Grab Year
            if(array_key_exists("year", $result)){
                $year_result = $result['year'];
                $year = Factory::createYear($year_result);
                $test->setYear($year);
            }
            return $test;

        }

        return null;
    }
    
    public static function createYear($result){

        if($result) {
            return new Year($result["yearId"],
                $result["description"],
                $result["year"],
                $result["open"],
                $result["openTest"],
                $result["resultsArePublic"]
            );
        }
    
    }

    public static function createGrade($result){

        if($result) {
            return new Grade($result["gradeId"],
                $result["name"],
                $result["order"]
            );
        }

    }

    

    
    
    
    
}