<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 9:58 AM
 */
class YearService implements IRestService{
    
    public function get($id){
        try {
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());
            //build query: We will need school and school's child objects
            $year_result = $db->from("year")->where("yearId = ?", $id)->fetch();
            $year = Factory::createYear($year_result);
            return $year;
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function getByParent($parent_id)
    {
        // TODO: Implement getByParent() method.
    }

    public function getAll(){
        // TODO: Implement getAll() method.
    }

    public function find($parameters = array()){
        try {
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());

            if(isset($parameters['getActiveYear'])) {
                $year_result = $db->from("year")->where("open = ?", 1)->fetch();
                $year = Factory::createYear($year_result);
                return $year;
            }

        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function post(IEduObject $object)
    {
        // TODO: Implement post() method.
    }

    public function put(IEduObject $object)
    {
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object)
    {
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object)
    {
        // TODO: Implement delete() method.
    }


}