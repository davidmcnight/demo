<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 3:49 PM
 */
class SchoolService implements IRestService{
    
    public function get($id){
       try{
           //create DB connection and create query builder
           $db = new FluentPDO(Database::getInstance());


           //build query: We will need school and school's child objects
           $school_result = $db->from("school")->where("schoolId = ?", $id)->fetch();
           $league = $db->from("league")->where("leagueId = ?", $school_result['leagueId'])->fetch();
           $billing_address = $db->from("billing_address")->where("schoolId = ?", $id)->fetch();;
           $shipping_address = $db->from("shipping_address")->where("schoolId = ?", $id)->fetch();
           $users_result = $db->from("user")->where("schoolId = ?", $school_result['schoolId']);
           $school = Factory::createSchool($school_result);
           $school->setShippingAddress(Factory::createShippingAddress($shipping_address));
           $school->setBillingAddress(Factory::createBillingAddress($billing_address));
           $school->setLeague($league);

           $users = array();
           foreach($users_result as $user_result){
               $user = Factory::createUser($user_result);
               array_push($users, $user);
           }

           $school->setUsers($users);
           return $school;


       } catch (Exception $e){
           echo $e->getMessage();
       }
    }

    public function getByParent($parent_id){
        // TODO: Implement getByParent() method.
    }

    public function getAll(){
        try{
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());

            //build query: We will need school and school's child objects
            $results = $db->from("school")
                ->innerJoin("billing_address on school.schoolId = billing_address.schoolId")
                ->innerJoin("shipping_address on school.schoolId = shipping_address.schoolId")
                ->innerJoin("league on school.leagueId = league.leagueId")
                ->select("billing_address.*")
                ->select("shipping_address.*")
                ->select("league.*");

            //create array for school
            $schools = array();

            foreach($results as $result ){
                
                //create school
                $school = Factory::createSchool($result);

                //set related tables
                $school->setShippingAddress(Factory::createShippingAddress($result));
                $school->setBillingAddress(Factory::createBillingAddress($result));
                $school->setLeague(Factory::createLeague($result));
                
                //push to array
                array_push($schools, $school);
            }
            return $schools;

        } catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function find($parameters = array()){
        // TODO: Implement find() method.
    }

    public function post(IEduObject $object){
        try{

            $db = Database::getInstance();

            $statement = $db->prepare("INSERT INTO educontest_test.school 
            (name, contact, billingName, purchaseOrder, schoolEmail, phone, fax, 
              leagueId, created_at, updated_at) VALUES
               (:name, :contact, :billingName, :purchaseOrder, :schoolEmail, :phone, :fax,
               :leagueId, NOW(), NOW())
            ");
            
            //bind School values
            $statement->bindValue(':name', $object->getName());
            $statement->bindValue(':contact', $object->getContact());
            $statement->bindValue(':billingName', $object->getBillingName());
            $statement->bindValue(':purchaseOrder', $object->getPurchaseOrder());
            $statement->bindValue(':schoolEmail', $object->getSchoolEmail());
            $statement->bindValue(':phone', $object->getPhone());
            $statement->bindValue(':fax', $object->getFax());
            $statement->bindValue(':leagueId', $object->getLeague()->getLeagueId());
            $statement->execute();

            //get school auto increment 
            $id = $db->lastInsertId();

            //insert ShippingAddress
            $statement2 = $db->prepare("INSERT INTO educontest_test.shipping_address 
            (schoolId, address1, address2, city, state, zip, created_at, updated_at) VALUES 
            (:schooId, :address1, :address2, :city, :state, :zip, NOW(), NOW() )");

            //bind ShippingAddress values
            $statement2->bindValue(':schoolId', $id);
            $statement2->bindValue(':address1', $object->getShippingAddress()->getAddress1());
            $statement2->bindValue(':address2', $object->getShippingAddress()->getAddress2());
            $statement2->bindValue(':city', $object->getShippingAddress()->getCity());
            $statement2->bindValue(':state', $object->getShippingAddress()->getState());
            $statement2->bindValue(':zip', $object->getShippingAddress()->getZip());
            $statement2->execute();

            //insert BillingAddress
            $statement3 = $db->prepare("INSERT INTO educontest_test.billing_address 
            (schoolId, address1, address2, city, state, zip, created_at, updated_at) VALUES 
            (:schoolId, :address1, :address2, :city, :state, :zip, NOW(), NOW() )");

            //bind BillingAddress values
            $statement3->bindValue(':schoolId', $id);
            $statement3->bindValue(':address1', $object->getBillingAddress()->getAddress1());
            $statement3->bindValue(':address2', $object->getBillingAddress()->getAddress2());
            $statement3->bindValue(':city', $object->getBillingAddress()->getCity());
            $statement3->bindValue(':state', $object->getBillingAddress()->getState());
            $statement3->bindValue(':zip', $object->getBillingAddress()->getZip());
            $statement3->execute();

            //insert User
            $statement4 = $db->prepare("INSERT INTO educontest_test.user
            (schoolId, email, password, admin, created_at, updated_at)
            VALUES (:schoolId, :email, :password, 0 , NOW(), NOW())");

            //bind User values
            $statement4->bindValue(':schoolId', $id);
            $statement4->bindValue(':email', $object->getUsers()->getEmail());
            $statement4->bindValue(':password', $object->getUsers()->getPassword());
            $statement4->execute();




        }catch (Exception $e){
            echo $e->getMessage();
        }

    }

    public function put(IEduObject $object){
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object){
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object){
        // TODO: Implement delete() method.
    }

    public function getShippingAddress(){

    }

    public function getBillingAddress(){

    }



}