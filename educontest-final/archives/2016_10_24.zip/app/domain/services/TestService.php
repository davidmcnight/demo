<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/21/16
 * Time: 2:45 PM
 */
class TestService implements IRestService{
    
    public function get($id)
    {
        // TODO: Implement get() method.
    }

    public function getByParent($parent_id)
    {
        // TODO: Implement getByParent() method.
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }

    public function find($parameters = array()){
        $db = new FluentPDO(Database::getInstance());

        try{
            //if year is passed we are looking for the tests by year
            if(isset($parameters['year'])) {
                //set get active year as a param
                $params = array('getActiveYear' => 1);
                $year = Factory::createService("Year")->find($params);
                $results = $db->from("test")->where("yearId = ?", $year->getYearId());
                $tests = array();
                foreach ($results as $result) {
                    $test = Factory::createTest($result);
                    $test->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                    $test->setYear(Factory::createService("Year")->get($result["yearId"]));
                    array_push($tests, $test);
                }
                return $tests;
            }
        }catch (Exception $e){
                echo $e->getMessage();
        }
        return null;
    }

    public function post(IEduObject $object)
    {
        // TODO: Implement post() method.
    }

    public function put(IEduObject $object)
    {
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object)
    {
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object)
    {
        // TODO: Implement delete() method.
    }

    public function createSchoolTest(School $school, Test $test){

        try{
            $db = Database::getInstance();
            $statement = $db->prepare("INSERT INTO school_test
              (schoolId, testId) VALUES  (:schoolId, :testId)");
            $statement->bindValue(":schoolId", $school->getSchoolId());
            $statement->bindValue(":testId", $test->getTestId());
            $statement->execute();
        }catch (Exception $e){
            echo $e->getMessage();
        }


    }


    public function deleteSchoolTest($schoolId, $testId){
        try{
            $db = Database::getInstance();
            $statement = $db->prepare("DELETE FROM school_test
              WHERE schoolId = :schoolId AND testId = :testId");
            $statement->bindValue(":schoolId", $schoolId);
            $statement->bindValue(":testId", $testId);
            $statement->execute();
        }catch (Exception $e){
            echo $e->getMessage();
        }


    }

    public function getSchoolTestLists($schoolId){
        try{
            $db = Database::getInstance();

            //get active year first
            $params = array('getActiveYear' => 1);
            $year = Factory::createService("Year")->find($params);

            //get All competitions this year
            $params = array('year' => 1);
            $allCompetitions = $this->find($params);

            $query = "SELECT * FROM
            (SELECT test.testId, test.yearId, test.gradeId
              FROM test WHERE test.yearId = " . $year->getYearId() . " ) a
              LEFT OUTER JOIN
                (SELECT test.testId as testId2
                    FROM test
                JOIN school_test ON test.testId = school_test.testId
                JOIN school ON school.schoolId = school_test.schoolId
                AND school.schoolId = " . $schoolId . "
                AND test.yearId = " . $year->getYearId() . ") b
              ON (a.testId = b.testId2)
              WHERE b.testId2 is NULL;";
            $stmt = $db->query($query);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();

            $unsignedUp = array();
            foreach ($results as $result) {
                $test = Factory::createTest($result);
                $test->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                $test->setYear(Factory::createService("Year")->get($result["yearId"]));
                array_push($unsignedUp, $test);
            }

            $db2 = new FluentPDO(Database::getInstance());

            //get competitions signed up for
            $results2 = $db2->from("test")
                ->innerJoin("school_test on 
                test.testId = school_test.testId")
                ->where("test.yearId = ?", $year->getYearId())
                ->where("school_test.schoolId = ?", $schoolId );

            //package them up
            $signedUpTests = array();
            foreach ($results2 as $result) {
                $test = Factory::createTest($result);
                $test->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                $test->setYear(Factory::createService("Year")->get($result["yearId"]));
                array_push($signedUpTests, $test);
            }



            //return 2D array of competition objects
            $testLists = array(
                "signedUp" => $signedUpTests,
                "notSignedUp" => $unsignedUp
            );

            return $testLists;

        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

}