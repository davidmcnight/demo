<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/17/16
 * Time: 1:00 PM
 */
class CompetitionService implements IRestService{
    public function get($id){
        // TODO: Implement get() method.
    }

    public function getByParent($parent_id)
    {
        // TODO: Implement getByParent() method.
    }

    public function getAll(){
        // TODO: Implement getAll() method.
    }

    public function find($parameters = array()){
        try {
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());
            if(isset($parameters['year'])) {
                //set get active year as a param
                $params = array('getActiveYear' => 1);
                $year = Factory::createService("Year")->find($params);
                $results = $db->from("competition")->where("yearId = ?", $year->getYearId());
                $competitions = array();
                foreach ($results as $result) {
                    $competition = Factory::createCompetition($result);
                    $competition->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                    $competition->setYear(Factory::createService("Year")->get($result["yearId"]));
                    array_push($competitions, $competition);
                }
                return $competitions;
            }

        }catch (Exception $e){
            echo $e->getMessage();
        }
        
    }

    public function post(IEduObject $object){
        // TODO: Implement post() method.
    }

    public function put(IEduObject $object)
    {
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object)
    {
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object)
    {
        // TODO: Implement delete() method.
    }

    public function createSchoolCompetition(School $school, Competition $competition){

        try{
            $db = Database::getInstance();
            $statement = $db->prepare("INSERT INTO educontest_test.school_competition 
              (schoolId, competitionId) VALUES  (:schoolId, :competitionId)");
            $statement->bindValue(":schoolId", $school->getSchoolId());
            $statement->bindValue(":competitionId", $competition->getCompetitionId());
            $statement->execute();
        }catch (Exception $e){
            echo $e->getMessage();
        }
        
        
    }


    public function deleteSchoolCompetition($schoolId, $competitionId){
        try{
            $db = Database::getInstance();
            $statement = $db->prepare("DELETE FROM educontest_test.school_competition 
              WHERE schoolId = :schoolId AND competitionId = :competitionId");
            $statement->bindValue(":schoolId", $schoolId);
            $statement->bindValue(":competitionId", $competitionId);
            $statement->execute();
        }catch (Exception $e){
            echo $e->getMessage();
        }


    }

    public function getSchoolCompetitionLists($schoolId){
        try{
            $db = Database::getInstance();

            //get active year first
            $params = array('getActiveYear' => 1);
            $year = Factory::createService("Year")->find($params);

            //get All competitions this year
            $params = array('year' => 1);
            $allCompetitions = $this->find($params);
            $query = "SELECT  * FROM
            (SELECT competition.competitionId,  competition.yearId,  competition.gradeId
             FROM competition
             WHERE competition.yearId = ". $year->getYearId() . ") a
             LEFT OUTER JOIN
            (SELECT competition.competitionId as competitionId2
            FROM competition 
            JOIN school_competition 
              ON competition.competitionId = school_competition.competitionId
            JOIN school 
              ON school.schoolId = school_competition.schoolId
            AND school.schoolId = $schoolId
            AND competition.yearId = ". $year->getYearId() . ") b
            ON (a.competitionId = b.competitionId2)
            WHERE b.competitionId2 is NULL";

            $stmt = $db->query($query);
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();

            $unsignedUp = array();
            foreach ($results as $result) {
                $competition = Factory::createCompetition($result);
                $competition->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                $competition->setYear(Factory::createService("Year")->get($result["yearId"]));
                array_push($unsignedUp, $competition);
            }

            $db2 = new FluentPDO(Database::getInstance());

            //get competitions signed up for
            $results2 = $db2->from("competition")
                ->innerJoin("school_competition on 
                competition.competitionId = school_competition.competitionId")
                ->where("competition.yearId = ?", $year->getYearId())
                ->where("school_competition.schoolId = ?", $schoolId );

            //package them up
            $signedUpCompetitions = array();
            foreach ($results2 as $result) {
                $competition = Factory::createCompetition($result);
                $competition->setGrade(Factory::createService("Grade")->get($result["gradeId"]));
                $competition->setYear(Factory::createService("Year")->get($result["yearId"]));
                array_push($signedUpCompetitions, $competition);
            }



            //return 2D array of competition objects
            $competitionLists = array(
                "signedUp" => $signedUpCompetitions,
                "notSignedUp" => $unsignedUp
            );

            return $competitionLists;

        }catch (Exception $e){
            echo $e->getMessage();
        }
    }


}