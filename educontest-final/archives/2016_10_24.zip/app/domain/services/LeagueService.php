<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 10/4/16
 * Time: 3:27 PM
 */



class LeagueService implements IRestService{

    public function get($id){
        try {
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());
            //get result
            $result = $db->from("league")->where("league_id = ?", $id)->fetch();
            $league = Factory::createLeague($result);
            return $league;
        }catch (Exception $e){
            $e->getMessage();
        }
    }

    public function getByParent($parent_id){
        // TODO: Implement getByParent() method.
    }

    public function getAll(){
        try {
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());
            //get results
            $results = $db->from("league");
            $leagues = array();
            //loop through results and add to array
            foreach($results as $result ) {
                $league = Factory::createLeague($result);
                array_push($leagues, $league);
            }
            return $leagues;
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function find($parameters = array())
    {
        // TODO: Implement find() method.
    }

    public function post(IEduObject $object)
    {
        // TODO: Implement post() method.
    }

    public function put(IEduObject $object)
    {
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object)
    {
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object)
    {
        // TODO: Implement delete() method.
    }


}