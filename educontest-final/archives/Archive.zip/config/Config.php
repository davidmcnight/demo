<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/26/16
 * Time: 11:20 AM
 */

//Config file that has all the DB information on it.

class Config{

    const DSN = "mysql:host=localhost;dbname=educontest_test";
    const DB_USERNAME = "root";
    const DB_PASSWORD = "root";

}