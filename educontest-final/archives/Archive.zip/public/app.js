/**
 * Created by dmcnight on 9/30/16.
 */


   var edu = angular.module('edu',[]);

   edu.controller('eduController', ['$scope','$http', function($scope, $http) {
     
       $scope.getSchool = function (id) {
           $http.get("/api/School/" + id).success(function (response) {
               $scope.school = response;
               console.log($scope.school)
           });
       }

       $scope.getAllSchools = function () {
           $http.get("/api/School/").success(function (response) {
               $scope.schools = response;
               console.log($scope.schools)
           });
       }

   }]);



   // edu.config(['$interpolateProvider', function ($interpolateProvider) {
   //     $interpolateProvider.startSymbol('[{[');
   //     $interpolateProvider.endSymbol(']}]');
   // }]);