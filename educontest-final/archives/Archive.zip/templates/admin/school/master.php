<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/30/16
 * Time: 3:54 PM
 */

require_once "templates/layout/header.php" 

?>

<div class="container" id="main" ng-app="edu" ng-controller="eduController"
     ng-init="getAllSchools()">
    <div class="col-xs-12 row mt2 mb2">
        <h1>Schools</h1>
    </div>
    <div class="col-md-12 row mb2">
        <div class="pull-left">
            <label for="search">Search:</label>
            <input ng-model="filter" id="search" class="form-control" placeholder="Filter text">
        </div>
        <div class="pull-right">
            <button class="btn btn-primary pull-right mt1">Add School</button>
        </div>

    </div>
    <div class="col-xs-12 row">
        <div class="panel panel-default">
            <div class="panel-heading">
                Schools
            </div>
            <table class="table table-striped">
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Address 1</th>
                    <th>City</th>
                    <th>ST</th>
                   
                </tr>
                <tr ng-repeat="school in schools | filter:filter : false">
                    <td class="bold">{{school.schoolId}}</td>
                    <td><a href="/admin/school/{{school.schoolId}}">{{school.name}}</td>
                    <td class="bold">{{school.contact}}</td>
                    <td>{{school.shippingAddress.address1}}</td>
                    <td>{{school.shippingAddress.city}}</td>
                    <td>{{school.shippingAddress.state}}</td>
                </tr>
            </table>
        </div>
    </div>
</div>
