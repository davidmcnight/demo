<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 3:52 PM
 */


/* This is the factory class. All Services or Models will be created in this class.
 * If you are creating those two categories of objects any other way than this you are doing it wrong.
 * This creates flexibility and scalability for this application. If a column is added to a table
 * and need to map it to a model class the only place we need to change the constructor outside the
 * the model class will be here.
 * Obviously if a whole new table is created -- this will change constructors in other places
 * For created a service --- we pass in the model class name and create a service from there.
 * For models we pass an array in (result from database) and child classes if it has any (School has 3)
 * Any questions consult the factory design pattern -- it is all over the web
 */

//This uses the singleton Design pattern. Sorry, if you do not like this pattern.
class Factory{

    private static $instance;

    /**
     * Protected constructor to prevent creating a new instance of the
     * *Singleton* via the `new` operator from outside of this class.
     */
    protected function __construct(){

    }
    /**
     * Returns the *Singleton* instance of this class.
     *
     * @return Singleton The *Singleton* instance.
     */
    public static function getInstance(){
        if (null === static::$instance) {
            static::$instance = new Factory();
        }
        return static::$instance;
    }

    //Creates service from model name -- thank PHP for how easy this is.
    public function getService($className){
        if($className){
            $serviceClass = $className . "Service";
            return new $serviceClass;
        }
        return null;
    }

    /* OBJECTS ASSOCIATED WITH SCHOOL */

    //initiates a School Object from the DB record and the below 3 objects
    public static function createSchool($result, $shipping_address, $billing_address, $league){
        if($result) {
            return new School($result["school_id"],
                $result["name"],
                $result["contact"],
                $result["billing_name"],
                $result["purchase_order"],
                $result["email"],
                $result["phone"],
                $result["fax"],
                $shipping_address,
                $billing_address,
                $league
            );
        }
        return null;

    }

    //initiates a League Object from the DB record
    public static function createLeague($result){
        if($result){
            return new League(
                $result["league_id"],
                $result["description"]
            );
        }
        return null;
    }

    //initiates a Shipping Address Object from the DB record
    public static function createShippingAddress($result){
        if($result){
            return new ShippingAddress($result["shipping_address_id"],
                $result["shipping_address1"],
                $result["shipping_address2"],
                $result["shipping_city"],
                $result["shipping_state"],
                $result["shipping_zip"]
            );
        }
        return null;
    }

    //initiates a Billing Address Object from the DB record
    public static function createBillingAddress($result){
        if($result){
            return new BillingAddress($result["billing_address_id"],
                $result["billing_address1"],
                $result["billing_address2"],
                $result["billing_city"],
                $result["billing_state"],
                $result["billing_zip"]
            );
        }
        return null;
    }


    

    
    
    
    
}