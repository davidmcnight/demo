<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 1:11 PM
 */


interface IRestService{
    
    //GET and Find
    public function get($id);
    public function getByParent($parent_id);
    public function getAll();
    public function find($parameters = array());
    
    //POST -- Create
    public function post(IEduObject $object);
    
    //PUT AND PATCH -- Update
    public function put(IEduObject $object);
    public function patch(IEduObject $object);
    
    //DELETE
    public function delete(IEduObject $object);
    
    
    

}