<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/26/16
 * Time: 11:53 AM
 */
class UserService{


    public function getUsers(){
        try{

        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function getUser(User $user){

    }

}