<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 3:49 PM
 */
class SchoolService implements IRestService{
    
    public function get($id){
       try{
           //create DB connection and create query builder
           $db = new FluentPDO(Database::getInstance());

           //build query: We will need school and school's child objects
           $result = $db->from("school")
               ->innerJoin("billing_address on school.school_id = billing_address.school_id")
               ->innerJoin("shipping_address on school.school_id = shipping_address.school_id")
               ->innerJoin("league on school.league_id = league.league_id")
               ->select("billing_address.*")
               ->select("shipping_address.*")
               ->select("league.*")
               ->where("school.school_id = ?", $id)
               ->fetch(); //fetch grabs the first item  if not used array is returned

           //crete child items
           $shippingAddress = Factory::createShippingAddress($result);
           $billingAddress = Factory::createBillingAddress($result);
           $league = Factory::createLeague($result);

           //create school child items as parameters
           $school = Factory::createSchool($result, $shippingAddress, $billingAddress, $league);
           return $school;

       } catch (Exception $e){
           $e->getMessage();
       }
    }

    public function getByParent($parent_id){
        // TODO: Implement getByParent() method.
    }

    public function getAll(){
        try{
            //create DB connection and create query builder
            $db = new FluentPDO(Database::getInstance());

            //build query: We will need school and school's child objects
            $results = $db->from("school")
                ->innerJoin("billing_address on school.school_id = billing_address.school_id")
                ->innerJoin("shipping_address on school.school_id = shipping_address.school_id")
                ->innerJoin("league on school.league_id = league.league_id")
                ->select("billing_address.*")
                ->select("shipping_address.*")
                ->select("league.*");

            //create array for school
            $schools = array();

            foreach($results as $result ){
                //create child items
                $shippingAddress = Factory::createShippingAddress($result);
                $billingAddress = Factory::createBillingAddress($result);
                $league = Factory::createLeague($result);

                //create school child items as parameters
                $school = Factory::createSchool($result, $shippingAddress, $billingAddress, $league);
                
                //push to array
                array_push($schools, $school);
            }
            return $schools;

        } catch (Exception $e){
            $e->getMessage();
        }
    }

    public function find($parameters = array()){
        // TODO: Implement find() method.
    }

    public function post(IEduObject $object){
        // TODO: Implement post() method.
    }

    public function put(IEduObject $object){
        // TODO: Implement put() method.
    }

    public function patch(IEduObject $object){
        // TODO: Implement patch() method.
    }

    public function delete(IEduObject $object){
        // TODO: Implement delete() method.
    }

    public function getShippingAddress(){

    }

    public function getBillingAddress(){

    }


}