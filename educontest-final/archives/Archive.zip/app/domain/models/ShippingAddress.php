<?php

/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 9:45 AM
 */
class ShippingAddress implements JsonSerializable, IEduObject{

    private $shippingAddressId;
    private $address1;
    private $address2;
    private $city;
    private $state;
    private $zip;
    private $createdAt;
    private $updatedAt;

    /**
     * ShippingAddress constructor.
     * @param $shippingAddressId
     * @param $address1
     * @param $address2
     * @param $city
     * @param $state
     * @param $zip
     */
    public function __construct($shippingAddressId, $address1, $address2, $city, $state, $zip){
        $this->shippingAddressId = $shippingAddressId;
        $this->address1 = $address1;
        $this->address2 = $address2;
        $this->city = $city;
        $this->state = $state;
        $this->zip = $zip;
    }


    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }

    public function jsonSerialize(){
        return get_object_vars($this);
    }
    

}