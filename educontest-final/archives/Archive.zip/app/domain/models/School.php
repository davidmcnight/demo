<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 9/29/16
 * Time: 9:32 AM
 */

class School implements JsonSerializable, IEduObject{

    private $schoolId;
    private $name;
    private $contact;
    private $billingName;
    private $purchaseOrder;
    private $email;
    private $phone;
    private $fax;
    private $shippingAddress;
    private $billingAddress;
    private $league;
    private $oldSchoolId;
    private $createdAt;
    private $updatedAt;

    /**
     * School constructor.
     * @param $schoolId
     * @param $name
     * @param $contact
     * @param $billingName
     * @param $purchaseOrder
     * @param $email
     * @param $phone
     * @param $fax
     * @param $shippingAddress
     * @param $billingAddress
     * @param $league
     */
    public function __construct($schoolId, $name, $contact, $billingName,
                                $purchaseOrder, $email, $phone, $fax, $shippingAddress,
                                $billingAddress, $league){
        $this->schoolId = $schoolId;
        $this->name = $name;
        $this->contact = $contact;
        $this->billingName = $billingName;
        $this->purchaseOrder = $purchaseOrder;
        $this->email = $email;
        $this->phone = $phone;
        $this->fax = $fax;
        $this->shippingAddress = $shippingAddress;
        $this->billingAddress = $billingAddress;
        $this->league = $league;
    }


    public function setFields($results){
        // TODO: Implement setFields() method.
    }

    public function getSource(){
        // TODO: Implement getSource() method.
    }


    public function jsonSerialize(){
        return get_object_vars($this);
    }





}