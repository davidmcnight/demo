create trigger specbk_last_spec_updated_price
  after INSERT
  on specbk_spec_prices_old
  for each row
  BEGIN
DECLARE specCount INT(11);
DECLARE previousPrice FLOAT;
	SELECT COUNT(*) INTO specCount FROM specbk_last_spec_updated_price WHERE specID = new.specID AND userID = new.userID;
	IF specCount < 1 THEN
  		INSERT INTO specbk_last_spec_updated_price (userID, specID, price, priceTimestamp) VALUES (new.userID, new.SpecID, new.price, NOW());
  	END IF;
  	IF specCount > 0 THEN
  		SELECT price INTO previousPrice FROM specbk_last_spec_updated_price WHERE specID = new.specID AND userID = new.userID;
  		IF previousPrice != new.price THEN
  			UPDATE specbk_last_spec_updated_price SET price = new.price, priceTimestamp = NOW() WHERE specID = new.SpecID AND userID = new.userID;
  		END IF;
  	END IF;
END;

