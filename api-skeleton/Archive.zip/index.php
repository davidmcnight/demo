<?php
/**
 * Step 1: Require the Slim Framework
 *
 * If you are not using Composer, you need to require the
 * Slim Framework and register its PSR-0 autoloader.
 *
 * If you are using Composer, you can skip this step.
 */


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function printNicely($value){
    print nl2br(print_r($value, true));
}




header('Access-Control-Allow-Origin: *');


//ini_set('memory_limit','1000M');

//foreach (glob("app/MoaMag/api/*.php") as $filename) {require_once $filename;}

require 'Slim/Slim.php';
//require_once "Config.php";
require_once "vendor/autoload.php";

\Slim\Slim::registerAutoloader();

//Config::init();



/**
 * Step 2: Instantiate a Slim application
 *
 * This example instantiates a Slim application using
 * its default settings. However, you will usually configure
 * your Slim application now by passing an associative array
 * of setting names and values into the application constructor.
 */
$app = new \Slim\Slim();


/**
 * Step 3: Define the Slim application routes
 *
 * Here we define several Slim application routes that respond
 * to appropriate HTTP request methods. In this example, the second
 * argument for `Slim::get`, `Slim::post`, `Slim::put`, `Slim::patch`, and `Slim::delete`
 * is an anonymous function.
 */


//SET CONDITIONS
\Slim\Route::setDefaultConditions(array(
    'class' => '[a-zA-Z]{3,}',
    'parent' => '[a-zA-Z]{3,}',
    'child' => '[a-zA-Z]{3,}',
    'foreignClass' => '[a-zA-Z]{3,}',
    'fk' => '[0-9]{0,10000}',
    'id' =>'[0-9]{0,10000}'
));


//Database connections
$settings = array(

    'default' => 'sqlsrv',
    'connections' => array(
        'resp' => array(
            'driver' => 'sqlsrv',
            'host' => 'SRVSQL01',
            'database' => 'R4W_primary;ConnectionPooling=0;',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        ),

        'pattern' => array(
            'driver' => 'sqlsrv',
            'host' => 'SRVSQL01',
            'database' => 'NBMS',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        )
//    ,
//        'moa' => array(
//            'driver' => 'sqlsrv',
//            'host' => 'SRVSQL01',
//            'database' => 'MOA_Master',
//            'username' => 'sa',
//            'password' => 'm2a2oh58',
//            'collation' => 'utf8_general_ci',
//            'prefix' => ''
//        )
        ,
        'moa' => array(
            'driver' => 'sqlsrv',
            'host' => 'SRVSQL01',
            'database' => 'MOA_MasterTest',
            'username' => 'sa',
            'password' => 'm2a2oh58',
            'collation' => 'utf8_general_ci',
            'prefix' => ''
        )
    )

);


//bootstrapping everything
$container = new Illuminate\Container\Container;
$connFactory = new \Illuminate\Database\Connectors\ConnectionFactory($container);
$resp = $connFactory->make($settings["connections"]["resp"]);
$resp1 = $connFactory->make($settings["connections"]["moa"]);
$resp2 = $connFactory->make($settings["connections"]["pattern"]);
$resolver = new \Illuminate\Database\ConnectionResolver();
$resolver->addConnection('resp', $resp);
$resolver->addConnection('moa', $resp1);
$resolver->addConnection('pattern', $resp2);
$resolver->setDefaultConnection('resp');
\Illuminate\Database\Eloquent\Model::setConnectionResolver($resolver);

//required files (API) Namespaces in composer JSON
foreach (glob("app/MoaMaster/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/PatriotIssue/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/Magento/api/*.php") as $filename) {require_once $filename;}
foreach (glob("app/api/interfaces/*.php") as $filename) {require_once $filename;}

use Magento\Config\Config as MagConfig;
//test urls
$app->get(
    '/',
    function () use ($app) {
        try{
            $dbc = new \PDO(MagConfig::$magDSN,MagConfig::$magUser, MagConfig::$magPassword );
            if(isset($parameters["getImage"])){
                if ($parameters["sku"]){

                }else{
                    return;
                }
            }
            printNicely($dbc);
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }
);


$app->get(
    '/ssh',
    function () use ($app) {

    }
);


// run app
$app->run();
