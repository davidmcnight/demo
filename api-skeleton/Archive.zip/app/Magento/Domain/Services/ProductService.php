<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 3:53 PM
 */

namespace Magento\Domain\Services;
use MedalsObject\IRestService;
use Magento\Config\Config as MagConfig;
use PHPMailer\PHPMailer\Exception;
use Magento\Helpers\QueryBuilder;

class ProductService implements IRestService{

    public function get($id){
        // TODO: Implement get() method.
    }

    public function getAll()
    {
        // TODO: Implement getAll() method.
    }

    public function getChildren($id, $childClass)
    {
        // TODO: Implement getChildren() method.
    }

    public function getByForeignKey($fk, $foreignClass){
        // TODO: Implement getByForeignKey() method.
    }

    public function find($parameters = array()){
        try{
            $dbc = new \PDO(MagConfig::$magDSN,MagConfig::$magUser, MagConfig::$magPassword );
            if(isset($parameters["getImage"])){
                if ($parameters["sku"]){
                    $sku = $parameters["sku"];
                    $query = QueryBuilder::getBaseQuery();
                    $query = $query . " WHERE e.sku = '" . $sku . "'  GROUP BY e.row_id";
                    $statement = $dbc->query($query);
                    $result = $statement->fetch(\PDO::FETCH_ASSOC);
                    $sku = $result["sku"];
                    $image = $result["image"];
                    return array("success"=>true,"sku"=>$sku, "image"=>"https://www.medalsofamerica.com/pub/media/catalog/product". $image);
                }else{
                    return array("success"=>false, "image"=>" There was no sku given. Please try again.");
                }
            }else{

            }
        }catch (Exception $e){
            echo $e->getMessage();
        }
    }

    public function post($data)
    {
        // TODO: Implement post() method.
    }

    public function put($data)
    {
        // TODO: Implement put() method.
    }

    public function patch($data)
    {
        // TODO: Implement patch() method.
    }

    public function delete($id)
    {
        // TODO: Implement delete() method.
    }


}
