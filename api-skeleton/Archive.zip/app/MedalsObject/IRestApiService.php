<?php
/**
 * Created by PhpStorm.
 * User: dmcnight
 * Date: 2/28/18
 * Time: 3:52 PM
 */

namespace MedalsObject;


interface IRestApiService{

}